import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import { Shooter, Projectile, LevelConfig, GameStatus, PixelColor } from '../types';
import { MAX_RACK_SIZE, MAX_PATH_SHOOTERS, SHOOT_INTERVAL, MOVE_SPEED, PADDING, PROJECTILE_SPEED } from '../constants';

interface GameBoardProps {
  levelConfig: LevelConfig;
  status: GameStatus;
  onGameOver: () => void;
  onWin: () => void;
}

interface PoolShooter {
  id: string;
  color: string;
  ammo: number;
}

interface DeploymentState {
  lanes: PoolShooter[][];
}

const LANES_COUNT = 3;
const PATH_PIXEL_DISTANCE = 48; 
// Reduced from 120 to 8 for sharp corners
const PATH_CORNER_RADIUS_PX = 8; 

const GameBoard: React.FC<GameBoardProps> = ({ levelConfig, status, onGameOver, onWin }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [grid, setGrid] = useState<PixelColor[][]>([]);
  const targetedPixelsRef = useRef<Set<string>>(new Set());
  
  const [shooters, setShooters] = useState<Shooter[]>([]);
  const [rack, setRack] = useState<Shooter[]>([]);
  const [projectiles, setProjectiles] = useState<Projectile[]>([]);
  const [deployment, setDeployment] = useState<DeploymentState>({
    lanes: Array(LANES_COUNT).fill(null).map(() => [])
  });
  
  const lastShootTimeRef = useRef<number>(0);
  const requestRef = useRef<number | undefined>(undefined);

  const [metrics, setMetrics] = useState({ totalPixels: 0, remainingPixels: 0, totalAmmo: 0 });

  const totalSoldiersLeft = useMemo(() => {
    return shooters.length + rack.length + deployment.lanes.flat().length;
  }, [shooters.length, rack.length, deployment.lanes]);

  useEffect(() => {
    const counts: Record<string, number> = {};
    const newGrid: PixelColor[][] = Array(levelConfig.gridSize).fill(null).map(() => 
      Array(levelConfig.gridSize).fill(null).map(() => {
        const rand = Math.random();
        if (rand < 0.15) return 'transparent'; 
        const color = levelConfig.colors[Math.floor(Math.random() * levelConfig.colors.length)];
        counts[color] = (counts[color] || 0) + 1;
        return color;
      })
    );

    const totalPixels = Object.values(counts).reduce((a, b) => a + b, 0);
    targetedPixelsRef.current = new Set();

    let targetSoldierCount = Math.min(100, Math.max(8, Math.floor(totalPixels / 15)));
    targetSoldierCount = Math.min(targetSoldierCount, totalPixels);

    const allShooters: PoolShooter[] = [];
    const colors = Object.keys(counts);
    let distributedSoldiers = 0;
    let actualTotalAmmo = 0;

    colors.forEach((color, idx) => {
      const colorPixels = counts[color];
      let soldiersForThisColor = Math.round((colorPixels / totalPixels) * targetSoldierCount);
      soldiersForThisColor = Math.max(1, Math.min(soldiersForThisColor, colorPixels));

      // Fixed typo: distributedSoldIris -> distributedSoldiers
      if (idx === colors.length - 1) {
        const needed = targetSoldierCount - distributedSoldiers;
        if (needed > 0) {
          soldiersForThisColor = Math.min(needed, colorPixels);
        }
      }
      
      distributedSoldiers += soldiersForThisColor;

      const baseAmmo = Math.floor(colorPixels / soldiersForThisColor);
      let remainder = colorPixels % soldiersForThisColor;

      for (let i = 0; i < soldiersForThisColor; i++) {
        const ammo = baseAmmo + (remainder > 0 ? 1 : 0);
        if (remainder > 0) remainder--;
        
        if (ammo > 0) {
          allShooters.push({
            id: Math.random().toString(36).substr(2, 9),
            color,
            ammo
          });
          actualTotalAmmo += ammo;
        }
      }
    });

    for (let i = allShooters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allShooters[i], allShooters[j]] = [allShooters[j], allShooters[i]];
    }

    const newLanes: PoolShooter[][] = Array(LANES_COUNT).fill(null).map(() => []);
    allShooters.forEach((s, idx) => {
      newLanes[idx % LANES_COUNT].push(s);
    });

    setGrid(newGrid);
    setShooters([]);
    setRack([]);
    setProjectiles([]);
    setDeployment({ lanes: newLanes });
    setMetrics({ totalPixels, remainingPixels: totalPixels, totalAmmo: actualTotalAmmo });
  }, [levelConfig]);

  const spawnShooter = useCallback((laneIndex: number) => {
    if (status !== GameStatus.PLAYING) return;
    if (shooters.length >= MAX_PATH_SHOOTERS) return;
    
    const lane = deployment.lanes[laneIndex];
    if (!lane || lane.length === 0) return;

    const picked = lane[0];
    const startProgress = shooters.some(s => s.progress < 0.02) ? -0.015 : 0;
    
    const newShooter: Shooter = {
      id: picked.id,
      color: picked.color,
      ammo: picked.ammo,
      maxAmmo: picked.ammo,
      progress: startProgress,
      status: 'PATH',
      x: 0,
      y: 0,
    };

    setShooters(prev => [...prev, newShooter]);
    setDeployment(prev => ({
      lanes: prev.lanes.map((l, idx) => idx === laneIndex ? l.slice(1) : l)
    }));
  }, [status, shooters.length, deployment]);

  const spawnFromRack = useCallback((index: number) => {
    if (status !== GameStatus.PLAYING) return;
    if (shooters.length >= MAX_PATH_SHOOTERS) return;
    
    const shooterToSpawn = rack[index];
    if (!shooterToSpawn) return;

    setRack(prev => prev.filter((_, i) => i !== index));
    setShooters(prev => [...prev, { ...shooterToSpawn, progress: 0, status: 'PATH' }]);
  }, [status, shooters.length, rack]);

  const getPathPosition = useCallback((progress: number, size: number, cellSize: number) => {
    const p = ((progress % 1) + 1) % 1; 
    const d = PATH_PIXEL_DISTANCE / cellSize;
    let r = PATH_CORNER_RADIUS_PX / cellSize;

    const width = size + 2 * d;
    const height = size + 2 * d;
    r = Math.min(r, width / 2, height / 2);

    const sW = width - 2 * r;
    const sH = height - 2 * r;
    const arc = (Math.PI * r) / 2;
    const totalLen = 2 * sW + 2 * sH + 4 * arc;
    const currentLen = p * totalLen;

    if (currentLen < sW) {
      return { x: -d + r + currentLen, y: size + d, side: 0 };
    } else if (currentLen < sW + arc) {
      const ang = (currentLen - sW) / arc * (Math.PI / 2);
      return { x: size + d - r + Math.sin(ang) * r, y: size + d - r + Math.cos(ang) * r, side: 4 }; 
    } else if (currentLen < sW + arc + sH) {
      return { x: size + d, y: size + d - r - (currentLen - (sW + arc)), side: 3 };
    } else if (currentLen < sW + arc + sH + arc) {
      const ang = (currentLen - (sW + arc + sH)) / arc * (Math.PI / 2);
      return { x: size + d - r + Math.cos(ang) * r, y: -d + r - Math.sin(ang) * r, side: 5 }; 
    } else if (currentLen < 2 * sW + 2 * arc + sH) {
      return { x: size + d - r - (currentLen - (sW + 2 * arc + sH)), y: -d, side: 2 };
    } else if (currentLen < 2 * sW + 3 * arc + sH) {
      const ang = (currentLen - (2 * sW + 2 * arc + sH)) / arc * (Math.PI / 2);
      return { x: -d + r - Math.sin(ang) * r, y: -d + r - Math.cos(ang) * r, side: 6 }; 
    } else if (currentLen < 2 * sW + 3 * arc + 2 * sH) {
      return { x: -d, y: -d + r + (currentLen - (2 * sW + 3 * arc + sH)), side: 1 };
    } else {
      const ang = (currentLen - (2 * sW + 3 * arc + 2 * sH)) / arc * (Math.PI / 2);
      return { x: -d + r - Math.cos(ang) * r, y: size + d - r + Math.sin(ang) * r, side: 7 }; 
    }
  }, []);

  const hasClearSight = useCallback((sx: number, sy: number, tx: number, ty: number, currentGrid: PixelColor[][], size: number, targetX: number, targetY: number) => {
    const dx = tx - sx;
    const dy = ty - sy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const steps = Math.ceil(dist * 6); 
    
    for (let i = 1; i < steps; i++) {
        const t = i / steps;
        const px = sx + dx * t;
        const py = sy + dy * t;
        const gx = Math.floor(px);
        const gy = Math.floor(py);
        if (gx >= 0 && gx < size && gy >= 0 && gy < size) {
            if (gx === targetX && gy === targetY) return true;
            if (currentGrid[gy][gx] !== 'transparent') return false;
        }
    }
    return true;
  }, []);

  const getTarget = useCallback((shooter: Shooter, currentGrid: PixelColor[][], size: number, targeted: Set<string>, cellSize: number) => {
    const { x: sx, y: sy } = getPathPosition(shooter.progress, size, cellSize);

    // Dynamic normal vector pointing directly towards the grid center
    const cx = size / 2;
    const cy = size / 2;
    const vToCenterX = cx - sx;
    const vToCenterY = cy - sy;
    const distToCenter = Math.sqrt(vToCenterX * vToCenterX + vToCenterY * vToCenterY);
    const nx = vToCenterX / distToCenter;
    const ny = vToCenterY / distToCenter;

    // Reduced firing cone to 2 degrees to strictly target pixels directly in front
    const cosThreshold = Math.cos(2 * Math.PI / 180); 
    const possibleTargets = [];
    
    for (let gy = 0; gy < size; gy++) {
      for (let gx = 0; gx < size; gx++) {
        if (currentGrid[gy][gx] === shooter.color && !targeted.has(`${gx},${gy}`)) {
          const tx = gx + 0.5; const ty = gy + 0.5;
          const vx = tx - sx; const vy = ty - sy;
          const dist = Math.sqrt(vx*vx + vy*vy);
          const ux = vx / dist; const uy = vy / dist;
          
          const dot = ux * nx + uy * ny;
          if (dot >= cosThreshold) {
            if (hasClearSight(sx, sy, tx, ty, currentGrid, size, gx, gy)) {
              possibleTargets.push({ gx, gy, distSq: vx*vx + vy*vy });
            }
          }
        }
      }
    }
    
    if (possibleTargets.length === 0) return null;
    possibleTargets.sort((a, b) => a.distSq - b.distSq);
    return { gridX: possibleTargets[0].gx, gridY: possibleTargets[0].gy };
  }, [getPathPosition, hasClearSight]);

  const update = useCallback((time: number) => {
    if (status !== GameStatus.PLAYING) {
      requestRef.current = requestAnimationFrame(update);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const canvasSize = canvas.width;
    const size = levelConfig.gridSize;
    const gridArea = canvasSize - (PADDING * 2);
    const cellSize = gridArea / size;
    const offsetX = PADDING;
    const offsetY = PADDING;

    const currentShootInterval = totalSoldiersLeft <= 5 ? SHOOT_INTERVAL / 2 : SHOOT_INTERVAL;
    const shouldShoot = time - lastShootTimeRef.current >= currentShootInterval;
    if (shouldShoot) lastShootTimeRef.current = time;

    const speedMultiplier = totalSoldiersLeft <= 5 ? 2 : 1;
    const currentMoveSpeed = MOVE_SPEED * speedMultiplier;

    setShooters(prevShooters => {
      const updatedShooters: Shooter[] = [];
      const newSettledToRack: Shooter[] = [];
      const newProjectiles: Projectile[] = [];

      for (let s of prevShooters) {
        s.progress += currentMoveSpeed;
        
        if (shouldShoot && s.ammo > 0) {
          const shotInfo = getTarget(s, grid, size, targetedPixelsRef.current, cellSize);
          if (shotInfo) {
            s.ammo--;
            targetedPixelsRef.current.add(`${shotInfo.gridX},${shotInfo.gridY}`);
            
            const { x: sx, y: sy } = getPathPosition(s.progress, size, cellSize);
            newProjectiles.push({
              id: Math.random().toString(36).substr(2, 9),
              x: offsetX + sx * cellSize,
              y: offsetY + sy * cellSize,
              targetX: offsetX + shotInfo.gridX * cellSize + cellSize / 2,
              targetY: offsetY + shotInfo.gridY * cellSize + cellSize / 2,
              gridX: shotInfo.gridX,
              gridY: shotInfo.gridY,
              color: s.color,
            });
          }
        }

        if (s.progress >= 1) {
          if (s.ammo > 0) {
            if (totalSoldiersLeft <= 5) {
              s.progress %= 1;
              updatedShooters.push(s);
            } else {
              newSettledToRack.push({ ...s, status: 'RACK' });
            }
          }
        } else if (s.ammo > 0) {
          updatedShooters.push(s);
        }
      }

      if (newProjectiles.length > 0) setProjectiles(p => [...p, ...newProjectiles]);
      if (newSettledToRack.length > 0) {
        setRack(currentRack => {
          const combined = [...currentRack, ...newSettledToRack];
          if (combined.length > MAX_RACK_SIZE) {
            onGameOver();
            return currentRack;
          }
          return combined;
        });
      }
      return updatedShooters;
    });

    setProjectiles(prev => {
      const active: Projectile[] = [];
      let gridChanged = false;
      let newGrid = [...grid.map(row => [...row])];

      for (let p of prev) {
        const dx = p.targetX - p.x;
        const dy = p.targetY - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < PROJECTILE_SPEED) {
          if (newGrid[p.gridY][p.gridX] === p.color) {
            newGrid[p.gridY][p.gridX] = 'transparent';
            gridChanged = true;
            targetedPixelsRef.current.delete(`${p.gridX},${p.gridY}`);
          }
        } else {
          const vx = (dx / dist) * PROJECTILE_SPEED;
          const vy = (dy / dist) * PROJECTILE_SPEED;
          active.push({ ...p, x: p.x + vx, y: p.y + vy });
        }
      }

      if (gridChanged) {
        setGrid(newGrid);
        const remainingCount = newGrid.flat().filter(c => c !== 'transparent').length;
        setMetrics(m => ({ ...m, remainingPixels: remainingCount }));
        if (remainingCount === 0) onWin();
      }
      return active;
    });

    const anyPool = deployment.lanes.some(l => l.length > 0);
    const anyRack = rack.length > 0;
    const anyActive = shooters.length > 0;
    const anyProjectiles = projectiles.length > 0;
    const anyPixels = grid.some(row => row.some(cell => cell !== 'transparent'));

    if (!anyPool && !anyRack && !anyActive && !anyProjectiles && anyPixels) {
      onGameOver();
    }

    requestRef.current = requestAnimationFrame(update);
  }, [status, grid, levelConfig.gridSize, onGameOver, onWin, rack, deployment, shooters, projectiles, getPathPosition, getTarget, totalSoldiersLeft]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [update]);

  useEffect(() => {
    const resizeCanvas = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;
      const rect = container.getBoundingClientRect();
      const size = Math.min(rect.width, rect.height);
      canvas.width = size;
      canvas.height = size;
    };
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = levelConfig.gridSize;
    const canvasSize = canvas.width;

    const render = () => {
      ctx.clearRect(0, 0, canvasSize, canvasSize);
      const gridArea = canvasSize - (PADDING * 2);
      const cellSize = gridArea / size;
      const offsetX = PADDING;
      const offsetY = PADDING;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.4)';
      ctx.roundRect(offsetX, offsetY, gridArea, gridArea, 8);
      ctx.fill();

      grid.forEach((row, r) => {
        row.forEach((cell, c) => {
          if (cell !== 'transparent') {
            ctx.fillStyle = cell; ctx.beginPath();
            ctx.roundRect(offsetX + c * cellSize + 0.5, offsetY + r * cellSize + 0.5, cellSize - 1, cellSize - 1, cellSize > 8 ? 3 : 0.5);
            ctx.fill(); ctx.shadowBlur = 8; ctx.shadowColor = cell; ctx.stroke(); ctx.shadowBlur = 0;
          } else {
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.015)'; ctx.strokeRect(offsetX + c * cellSize, offsetY + r * cellSize, cellSize, cellSize);
          }
        });
      });

      shooters.forEach(s => {
        const { x, y } = getPathPosition(s.progress, size, cellSize);
        const drawX = offsetX + x * cellSize;
        const drawY = offsetY + y * cellSize;
        ctx.fillStyle = s.color; ctx.beginPath(); ctx.arc(drawX, drawY, 14, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 15; ctx.shadowColor = s.color; ctx.strokeStyle = 'white'; ctx.lineWidth = 2; ctx.stroke(); ctx.shadowBlur = 0;
        ctx.fillStyle = 'white'; ctx.font = 'bold 12px Inter'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(s.ammo.toString(), drawX, drawY);
      });

      projectiles.forEach(p => {
        ctx.fillStyle = p.color; ctx.shadowBlur = 10; ctx.shadowColor = p.color; ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
      });
    };
    render();
  }, [grid, shooters, projectiles, levelConfig.gridSize, getPathPosition]);

  return (
    <div className="flex flex-col items-center w-full h-full">
      <div ref={containerRef} className="flex-grow w-full flex items-center justify-center relative p-2 overflow-hidden">
        <div className="absolute top-2 left-4 flex flex-col items-start gap-1 z-20">
          <div className="bg-slate-900/80 px-3 py-1 rounded-lg border border-slate-700/50 backdrop-blur flex flex-col">
            <div className="flex justify-between gap-4">
              <span className="text-slate-400 text-[8px] font-bold uppercase tracking-widest">Pixel Bank</span>
              <span className="text-white text-[9px] font-black">{metrics.remainingPixels}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400 text-[8px] font-bold uppercase tracking-widest">Active Ammo</span>
              <span className="text-emerald-400 text-[9px] font-black">
                {metrics.totalAmmo - (metrics.totalPixels - metrics.remainingPixels)}
              </span>
            </div>
            {totalSoldiersLeft <= 5 && (
              <div className="mt-1 px-1 bg-amber-500/20 rounded flex items-center gap-1 animate-pulse">
                <span className="text-amber-400 text-[7px] font-black uppercase tracking-tighter">MAX OVERDRIVE ACTIVE</span>
              </div>
            )}
          </div>
        </div>

        <canvas ref={canvasRef} className="rounded-2xl block bg-slate-900/10 shadow-inner max-w-full max-h-full aspect-square" />
        
        <div className="absolute top-2 right-4 flex flex-col items-end gap-1 z-20">
          <div className="bg-slate-950/60 px-2 py-1 rounded-full border border-slate-800 backdrop-blur-sm">
            <span className="text-slate-500 text-[8px] font-bold tracking-widest uppercase">
              {shooters.length}/{MAX_PATH_SHOOTERS} ACTIVE
            </span>
          </div>
        </div>
      </div>

      <div className="w-full max-w-xl px-4 py-4 flex flex-col gap-3 shrink-0">
        <div className="flex flex-col gap-1">
          <div className="flex justify-between items-center px-1">
            <span className="text-slate-500 text-[8px] font-bold uppercase tracking-widest">Reserve Rack</span>
            <span className={`text-[8px] font-bold uppercase ${rack.length >= MAX_RACK_SIZE ? 'text-rose-400 animate-pulse' : 'text-slate-600'}`}>
              {rack.length}/{MAX_RACK_SIZE} SLOTS
            </span>
          </div>
          <div className="flex gap-2 p-2 rounded-xl bg-slate-900/90 border border-slate-800/80 shadow-lg justify-center h-14 overflow-x-auto scrollbar-hide">
            {Array(MAX_RACK_SIZE).fill(null).map((_, i) => (
              <div key={i} className="w-10 h-10 shrink-0">
                {rack[i] ? (
                  <button
                    onClick={() => spawnFromRack(i)}
                    disabled={status !== GameStatus.PLAYING || shooters.length >= MAX_PATH_SHOOTERS}
                    className="w-full h-full rounded-full aspect-square flex flex-col items-center justify-center transition-all hover:scale-110 active:scale-90 disabled:opacity-40 disabled:grayscale group relative shadow-md border-2 border-white/20"
                    style={{ backgroundColor: rack[i].color }}
                  >
                    <span className="text-white font-black text-sm drop-shadow-sm">{rack[i].ammo}</span>
                    <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-full" />
                  </button>
                ) : (
                  <div className="w-full h-full rounded-full aspect-square border border-slate-800/50 flex items-center justify-center bg-slate-950/40 border-dashed">
                    <div className="w-1 h-1 rounded-full bg-slate-800/20" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <div className="flex justify-between items-center px-1">
            <span className="text-slate-500 text-[8px] font-bold uppercase tracking-widest">Marching Lanes</span>
            <span className="text-slate-600 text-[8px] font-bold uppercase tracking-widest">
              Queue: {deployment.lanes.flat().length} Units
            </span>
          </div>
          
          <div className="grid grid-cols-3 gap-4 p-2 rounded-xl bg-slate-800/10 border border-slate-700/20 backdrop-blur-sm h-36">
            {deployment.lanes.map((lane, laneIdx) => (
              <div key={laneIdx} className="relative h-full overflow-y-auto overflow-x-hidden scrollbar-hide flex flex-col items-center gap-2 p-1 rounded-lg bg-slate-900/30">
                {lane.length > 0 ? (
                  lane.map((s, rowIdx) => {
                    const isFront = rowIdx === 0;
                    return (
                      <button
                        key={s.id}
                        onClick={() => isFront && spawnShooter(laneIdx)}
                        disabled={!isFront || status !== GameStatus.PLAYING || shooters.length >= MAX_PATH_SHOOTERS}
                        className={`
                          relative w-10 aspect-square rounded-full flex flex-col items-center justify-center transition-all duration-300 shrink-0
                          ${isFront 
                            ? 'z-20 shadow-lg border-2 border-white/40 hover:scale-110 active:scale-95' 
                            : 'z-10 opacity-60 scale-75 border border-white/5'}
                          disabled:opacity-20
                        `}
                        style={{ 
                          backgroundColor: s.color,
                          boxShadow: isFront ? `0 4px 12px -2px ${s.color}aa` : 'none'
                        }}
                      >
                        <span className={`text-white font-black leading-none drop-shadow-sm ${isFront ? 'text-lg' : 'text-[10px]'}`}>
                          {s.ammo}
                        </span>
                      </button>
                    );
                  })
                ) : (
                  <div className="w-full h-full flex items-center justify-center border-2 border-slate-800/30 border-dashed rounded-lg">
                    <span className="text-slate-700 text-[8px] font-bold uppercase rotate-90 whitespace-nowrap">Depleted</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameBoard;