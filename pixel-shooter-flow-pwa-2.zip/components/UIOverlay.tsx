
import React from 'react';
import { GameStatus } from '../types';

interface UIOverlayProps {
  level: number;
  status: GameStatus;
  onNextLevel: () => void;
  onRestart: () => void;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ level, status, onNextLevel, onRestart }) => {
  if (status === GameStatus.PLAYING) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-xl transition-all duration-500">
      <div className="max-w-md w-full p-8 rounded-3xl border border-slate-800 bg-slate-900 shadow-2xl text-center flex flex-col items-center">
        
        {status === GameStatus.WON && (
          <>
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mb-6">
              <i className="fa-solid fa-check text-4xl text-emerald-400"></i>
            </div>
            <h1 className="text-4xl font-black italic tracking-tighter text-white mb-2">TARGETS NEUTRALIZED</h1>
            <p className="text-slate-400 text-sm mb-8 leading-relaxed">
              Level {level} grid successfully cleared. Advanced encryption detected in the next sector.
            </p>
            <button
              onClick={onNextLevel}
              className="w-full py-4 px-8 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl transition-all transform hover:scale-105 active:scale-95 uppercase tracking-widest shadow-[0_0_30px_rgba(16,185,129,0.3)]"
            >
              Access Sector {level + 1}
            </button>
          </>
        )}

        {status === GameStatus.LOST && (
          <>
            <div className="w-20 h-20 rounded-full bg-rose-500/20 flex items-center justify-center mb-6">
              <i className="fa-solid fa-triangle-exclamation text-4xl text-rose-400"></i>
            </div>
            <h1 className="text-4xl font-black italic tracking-tighter text-white mb-2">SYSTEM OVERLOAD</h1>
            <p className="text-slate-400 text-sm mb-8 leading-relaxed">
              Reserve rack capacity exceeded. Tactical retreat initiated. Neural link severed at level {level}.
            </p>
            <button
              onClick={onRestart}
              className="w-full py-4 px-8 bg-rose-500 hover:bg-rose-400 text-white font-black rounded-xl transition-all transform hover:scale-105 active:scale-95 uppercase tracking-widest shadow-[0_0_30px_rgba(244,63,94,0.3)]"
            >
              Initialize Reboot
            </button>
          </>
        )}

        <div className="mt-8 flex gap-2 items-center text-slate-600">
          <div className="w-2 h-2 rounded-full bg-slate-600 animate-pulse" />
          <span className="text-[10px] font-bold tracking-widest uppercase">End of Transmission</span>
        </div>
      </div>
    </div>
  );
};

export default UIOverlay;
